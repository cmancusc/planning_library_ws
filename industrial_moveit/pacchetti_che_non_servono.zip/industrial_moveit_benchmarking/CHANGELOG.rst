^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package industrial_moveit_benchmarking
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2017-03-24)
------------------

0.1.0 (2017-03-14)
------------------
* Initial release
* Contributors: Jonathan Meyer, Levi Armstrong, Jorge Nicho
