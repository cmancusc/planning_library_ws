Industrial Collision Detection
=====

This package started as a copy of the MoveIt! **collision_detection** library and was modified to include distance query  
 features.  Eventually these features were [added to MoveIt!](https://github.com/ros-planning/moveit/pull/662/files) so this package is now deprecated and developers are encouraged to use  
 the MoveIt! **collision_detection** library.  Nevertheless, this package will be kept around as there may be functionality that is relevant  
 to the **constrained_ik** package that was not ported over.
