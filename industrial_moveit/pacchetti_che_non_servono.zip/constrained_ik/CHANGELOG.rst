^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package constrained_ik
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2017-03-24)
------------------

0.1.0 (2017-03-14)
------------------
* Initial release
* Contributors: Jeremy Zoss, Levi Armstrong, Jonathan W Meyer, Dan Solomon
